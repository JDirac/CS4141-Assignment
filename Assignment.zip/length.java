
public class length {
   public int length() {
       
   String [] SheetNames = {"sheet1", "sheet2", "sheet3", "sheet4"};
       
   return SheetNames.length;  
       
       
       
       
       
       
       
       
       
       
   }
}
