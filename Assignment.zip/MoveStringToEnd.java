public class MoveStringToEnd {
    public static String[] Sheets = new String[256];
    
    public int moveToEnd(String from) {
        Sheets[0] = "Sheet1";
        Sheets[3] = "Sheet2";
        Sheets[2] = "Sheet3";
        int temp = -1;
        int to = -1;
        //Check if "from" exists in the array
        for(int a = 0; a < Sheets.length; a++) {
            if(Sheets[a] != null) {
                if((Sheets[a].toUpperCase()).equals(from.toUpperCase())) {
                temp = a;
                break;
                }
            }
        }
        //Find last Sheet in array
        for(int b = 0; b < Sheets.length; b++) {
            if(Sheets[b] != null) {
                to = b;
            }
        }
        // move "from" to after "to"
        if(temp != -1) {
           Sheets[to + 1] = Sheets[temp];
           Sheets[temp] = null;
           return temp;
        }
        return -1;
    }
}