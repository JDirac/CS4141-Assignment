
public class display {
    public void Display() {
    
    String [] SheetNames = {"sheet1", "sheet2", "sheet3", "sheet4"};
    
    int i = 0;
    
    for (i = 0; i < SheetNames.length; i++) {
        System.out.println(SheetNames[i]);
        
    }
    
  }
}
